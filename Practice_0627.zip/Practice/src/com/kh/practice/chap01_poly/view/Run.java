package com.kh.practice.chap01_poly.view;

public class Run {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
