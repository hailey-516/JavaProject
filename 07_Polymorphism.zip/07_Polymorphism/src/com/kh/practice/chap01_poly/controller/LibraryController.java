package com.kh.practice.chap01_poly.controller;

import com.kh.practice.chap01_poly.model.vo.Book;
import com.kh.practice.chap01_poly.model.vo.Member;

public class LibraryController {
	
	private Member mem = null;
	private Book[] bList = new Book[5];
	
	public void insertMember() {
		
	}
	
	public Member myinfo() {
		
	}
	
	public Book[] selectAll() {
		
	}
	
	public Book[] searchBook(String keword) {
		
	}
	
	public int rentBook(int index) {
		
	}

}
